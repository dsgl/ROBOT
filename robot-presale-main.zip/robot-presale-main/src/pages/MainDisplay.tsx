export default function MainDisplay() {
  return (
    <div>MainDisplay</div>
  )
}
